# Smart Syllabus

A free guidance website for IB Diploma students, hosted on GitHub Pages and edited through a dashboard at `/admin/`.

- **First-time setup:** [docs/SETUP.md](docs/SETUP.md)
- **How to edit content:** [docs/EDITING.md](docs/EDITING.md)

## How it fits together

```
Dashboard (/admin, Decap CMS) ──save──▶ content/*.json in this repository
        │ sign-in                              │ every save triggers
        ▼                                      ▼
Cloudflare Worker (worker/worker.js)    GitHub Actions: check → build → GitHub Pages
```

| Folder | What's in it |
|---|---|
| `content/` | All site content, written by the dashboard. Pages, notices, universities, settings. |
| `public/uploads/` | Files uploaded through the dashboard |
| `assets/` | Design: `reference.css` (original design, unchanged), `site.css` (additions), fonts |
| `build/` | The site builder. `render/` is shared with the dashboard preview. |
| `admin/` | Dashboard page and preview |
| `worker/` | Sign-in helper for Cloudflare |
| `tests/` | Automated checks (run on every publish) |

## For developers

```
npm install
npm run dev      # site at http://localhost:8080, dashboard at /admin (saves to this folder, no login)
npm test
npm run build    # outputs dist/
```
