# Smart Syllabus: one-time setup

About 30–40 minutes, once. Everything here is free. You'll never need to paste a password or secret into a chat, and none of them go into the website's files.

You'll create three things:

| What | Where | Why |
|---|---|---|
| A **public** GitHub repository | github.com | Stores the website and its content. Free GitHub Pages needs a public repository. |
| A **sign-in helper** (Cloudflare Worker) | dash.cloudflare.com | Lets the dashboard log you in with GitHub. GitHub Pages can't do this step itself. |
| A **GitHub OAuth app** | GitHub settings | Connects the two securely. |

> **Public repository means:** anyone can read the files on GitHub, including Draft pages and private notes in the dashboard. Drafts don't appear on the *website*, but don't put private information in them.

---

## Step 1: Put the code on GitHub

1. Create a free account at <https://github.com> if you don't have one.
2. Click **+ → New repository**. Name it `smart-syllabus`, choose **Public**, and click **Create repository**.
3. Upload the project files. The easiest reliable way is **GitHub Desktop** (<https://desktop.github.com>):
   1. **File → Clone repository**, pick `smart-syllabus`, choose a folder.
   2. Unzip `smart-syllabus.zip` and copy everything inside into that folder, **including the hidden `.github` folder**. (On Mac, press `Cmd+Shift+.` in Finder to show hidden folders. On Windows: View → Show → Hidden items.)
   3. In GitHub Desktop, type a summary like "First version" and click **Commit to main**, then **Push origin**.

   *Alternative:* connect GitHub to Claude and Claude can push the code for you.

## Step 2: Turn on GitHub Pages

1. In your repository: **Settings → Pages**.
2. Under **Build and deployment → Source**, choose **GitHub Actions**.
3. Go to the **Actions** tab. If "Publish website" ran before you did this and failed, click it and choose **Re-run all jobs**.
4. When it shows a green tick, your site is live at `https://YOUR-USERNAME.github.io/smart-syllabus/`.

The website works now. The next steps make the dashboard work.

## Step 3: Create the sign-in helper (Cloudflare Worker)

1. Create a free account at <https://dash.cloudflare.com>.
2. Go to **Workers & Pages → Create → Create Worker**. Name it e.g. `smart-syllabus-auth`, click **Deploy**.
3. Click **Edit code**. Delete everything in the editor, paste the whole contents of `worker/worker.js` from this project, click **Deploy**.
4. Note the Worker's address, e.g. `https://smart-syllabus-auth.YOUR-NAME.workers.dev`. Opening it should say *"The Smart Syllabus sign-in helper is running"* (or that settings are missing; that's expected until Step 5).

## Step 4: Create the GitHub OAuth app

1. On GitHub: your profile picture → **Settings → Developer settings → OAuth Apps → New OAuth App**.
2. Fill in:
   - **Application name:** Smart Syllabus dashboard
   - **Homepage URL:** `https://YOUR-USERNAME.github.io/smart-syllabus/`
   - **Authorization callback URL:** your Worker address + `/callback`, e.g. `https://smart-syllabus-auth.YOUR-NAME.workers.dev/callback`
3. Click **Register application**. Copy the **Client ID**.
4. Click **Generate a new client secret** and keep the page open. You'll paste the secret into Cloudflare only.

## Step 5: Give the Worker its settings

In Cloudflare: your Worker → **Settings → Variables and secrets → Add**:

| Type | Name | Value |
|---|---|---|
| Text | `GITHUB_CLIENT_ID` | the Client ID |
| **Secret** | `GITHUB_CLIENT_SECRET` | the client secret (choose type **Secret**) |
| Text | `ALLOWED_ORIGIN` | `https://YOUR-USERNAME.github.io` (no `/smart-syllabus`, no slash at the end) |

Click **Deploy** / **Save**.

## Step 6: Tell the website where the sign-in helper is

1. In your GitHub repository: **Settings → Secrets and variables → Actions → Variables** tab → **New repository variable**.
2. Name: `CMS_AUTH_URL`. Value: your Worker address, e.g. `https://smart-syllabus-auth.YOUR-NAME.workers.dev` (no slash at the end).
3. **Actions** tab → **Publish website** → **Run workflow** (or re-run the last run).

## Step 7: Sign in

1. Open `https://YOUR-USERNAME.github.io/smart-syllabus/admin/`.
2. Click **Login with GitHub** and approve. A small window opens and closes.
3. You're in. Only GitHub accounts with write access to your repository can save anything. Everyone else gets "no access".

**About permissions:** GitHub will ask to let the app access your *public repositories*. That's how GitHub permissions work for public repos. The login token stays in your browser and is only sent to GitHub.

---

## If something goes wrong

| Problem | Fix |
|---|---|
| Website shows 404 | Settings → Pages → Source must be **GitHub Actions**; check the Actions tab for a green tick. |
| Login window says settings are missing | Recheck Step 5 names (exact spelling) and click Deploy in Cloudflare. |
| Login window opens but nothing happens | `ALLOWED_ORIGIN` must exactly match `https://YOUR-USERNAME.github.io`. The callback URL in Step 4 must end in `/callback`. |
| "Repo not found" in the dashboard | You're signed in with a GitHub account that can't edit this repository. |
| Dashboard still asks for a GitHub token or shows "OWNER/REPOSITORY" | Step 6 wasn't applied yet: re-run the Publish website workflow. |
| A red ✗ in the Actions tab after saving | Open it. The summary explains in plain English what to fix (e.g. two pages with the same address). The live site keeps its last good version. |

## Custom domain (optional, later)

Settings → Pages → Custom domain. Then update `ALLOWED_ORIGIN` (Step 5) and the OAuth app's URLs (Step 4) to the new domain. Uploaded files keep working automatically.
