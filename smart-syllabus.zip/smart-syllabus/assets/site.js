// Mobile: the "Pages" button opens and closes the sidebar.
(function () {
  var t = document.querySelector('.menu-toggle');
  if (!t) return;
  t.addEventListener('click', function () {
    var open = document.body.classList.toggle('side-open');
    t.setAttribute('aria-expanded', open ? 'true' : 'false');
    t.textContent = open ? 'Close' : 'Pages';
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && document.body.classList.contains('side-open')) t.click(); });
})();
