import { test } from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/worker.js';

const env = { GITHUB_CLIENT_ID: 'cid', GITHUB_CLIENT_SECRET: 'secret', ALLOWED_ORIGIN: 'https://me.github.io' };
const W = 'https://auth.example.workers.dev';

test('refuses to run without settings', async () => {
  const r = await worker.fetch(new Request(W + '/auth'), {});
  assert.equal(r.status, 500);
  assert.match(await r.text(), /GITHUB_CLIENT_ID/);
});

test('/auth redirects to GitHub with a state cookie', async () => {
  const r = await worker.fetch(new Request(W + '/auth?provider=github&site_id=me.github.io&scope=repo'), env);
  assert.equal(r.status, 302);
  const loc = new URL(r.headers.get('location'));
  assert.equal(loc.origin + loc.pathname, 'https://github.com/login/oauth/authorize');
  assert.equal(loc.searchParams.get('client_id'), 'cid');
  assert.equal(loc.searchParams.get('redirect_uri'), W + '/callback');
  const state = loc.searchParams.get('state');
  assert.ok(state);
  assert.match(r.headers.get('set-cookie'), new RegExp(`ss_oauth_state=${state};.*HttpOnly; Secure`));
  assert.ok(!loc.toString().includes('secret'), 'secret never leaves the worker');
});

test('/callback rejects a mismatched state (CSRF protection)', async () => {
  const r = await worker.fetch(new Request(W + '/callback?code=abc&state=evil', { headers: { cookie: 'ss_oauth_state=good' } }), env);
  const html = await r.text();
  assert.match(html, /authorization:github:error/);
  assert.ok(!html.includes('access_token'));
});

test('/callback exchanges the code and only posts the token to the allowed origin', async () => {
  const realFetch = globalThis.fetch;
  let sent;
  globalThis.fetch = async (u, init) => { sent = { u, body: JSON.parse(init.body) }; return new Response(JSON.stringify({ access_token: 'gho_TEST</script>' }), { headers: { 'content-type': 'application/json' } }); };
  try {
    const r = await worker.fetch(new Request(W + '/callback?code=abc&state=s1', { headers: { cookie: 'x=1; ss_oauth_state=s1' } }), env);
    const html = await r.text();
    assert.equal(sent.u, 'https://github.com/login/oauth/access_token');
    assert.deepEqual([sent.body.client_id, sent.body.client_secret, sent.body.code], ['cid', 'secret', 'abc']);
    assert.match(html, /authorization:github:success/);
    assert.match(html, /var origin="https:\/\/me\.github\.io"/);
    assert.ok(!html.includes('"*"'), 'never posts to any origin');
    assert.ok(!html.includes('</script>"'), 'token text is escaped inside the script');
    assert.ok(!html.includes('secret'), 'client secret is not in the page');
  } finally { globalThis.fetch = realFetch; }
});

test('/callback reports GitHub errors', async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({ error: 'bad_verification_code', error_description: 'The code passed is incorrect or expired.' }));
  try {
    const r = await worker.fetch(new Request(W + '/callback?code=abc&state=s1', { headers: { cookie: 'ss_oauth_state=s1' } }), env);
    assert.match(await r.text(), /incorrect or expired/);
  } finally { globalThis.fetch = realFetch; }
});
